#include <util/delay.h>
#include <avr/io.h>
#include <stdlib.h>

float tension = 0.0;
float adc_vect = 0.0;
float sumatoria = 0.0;
uint8_t sum = 0;
uint8_t Samples = 100;
float V_rms = 0.0;
float V_med = 0.0;
uint8_t data_H;
uint8_t data_L;


uint8_t spi_Transfer(uint8_t datos)
{
	SPDR = datos;
	asm volatile("nop");
	while (!(SPSR & _BV(SPIF))) ; // Espera a recibir por SPI
	return SPDR;
}


float ADC_read()
{
	PORTB &= ~(1 << PB4);
	spi_Transfer(0b00000100);
	data_H = spi_Transfer(0x00);
	data_L = spi_Transfer(0x00);
	PORTB |= (1 << PB4);
	data_H <<= 4;
	uint16_t Valor_adc = data_H;
	Valor_adc <<= 4;
	Valor_adc |= data_L;
	float volt = Valor_adc * 5.05 / 4095.0 - V_med;
	return volt;
}

int main(void)
{

	DDRB |= (1 << DDB4) | (1 << DDB5) | (1 << DDB7);										// Salidas: MOSI, SCK y SS 
	PORTB |= (1 << PB4);
	SPCR |= (1 << SPE) | (1 << MSTR) | (1 << SPR0) | (1 << CPOL) | (1 << CPHA);				// Habilita SPI, maestro
	SPSR |= (1 << SPI2X);																	// SPI 2x para lograr 2 MHz
	DDRB &= ~(1 << DDB6);																	// MISO entrada
	
	while (sum < Samples)
	{
		adc_vect = ADC_read();
		sumatoria += adc_vect;
		sum++;
		_delay_us(1);
	}
	
	V_med =sumatoria / Samples;

	
	while (1)
	{
		
		sumatoria = 0.0;
		sum = 0;
		
		while (sum < Samples)
		{
			adc_vect = ADC_read();
			//sumatoria += adc_vect;
			sumatoria += adc_vect * adc_vect;
			sum++;
			_delay_us(1);
		}

		V_rms = sqrt(sumatoria / Samples);
		asm("nop");

	}
}
